import * as React from "react";
import { createHashRouter, RouterProvider, Outlet } from "react-router-dom";

import Layout from "./components/layout/layout";
import Landingpage from "./components/landingpage/landingpagefull";
import DetailPage from "./components/Pages/DetailPage/Index";

export default function AppRouter() {

  // Public routes (no admin logic)
  const routes: any[] = [
    {
      element: <Layout><Outlet /></Layout>,
      children: [
        // Home page
        { path: "/", element: <Landingpage /> },

        // Detail page for ALL lists
        { path: "detail/:listName/:id", element: <DetailPage /> },
      ],
    },
  ];

  const router = createHashRouter(routes);

  return <RouterProvider router={router} />;
}

// ./components/Events/index.tsx
import * as React from "react";
import { EventItem, EventsProps } from "../../../utils/types";

const Events: React.FC<EventsProps> = ({ mainEvent, sideEvents, onViewAll }) => {
  // safe guards
  const hasMain = Boolean(mainEvent);
  const hasSides = Array.isArray(sideEvents) && sideEvents.length > 0;

  return (
    <div className="lp-card lp-event-card">
      <div className="lp-section-header">
        <h3>Events</h3>
        {onViewAll ? (
          <button className="lp-viewall" onClick={onViewAll}>
            View all ➜
          </button>
        ) : (
          <button className="lp-viewall">View all ➜</button>
        )}
      </div>

      <div className="lp-events-grid">
        {/* MAIN EVENT */}
        <div className="lp-event-main">
          {hasMain ? (
            <>
              <img
                src={(mainEvent as EventItem).image || ""}
                alt={(mainEvent as EventItem).alt || "event"}
                className="lp-event-main-img"
              />
              <h4 className="lp-event-title">{(mainEvent as EventItem).title}</h4>
              <p className="lp-event-sub">{(mainEvent as EventItem).description}</p>
              <div className="lp-small-date">{(mainEvent as EventItem).date}</div>
            </>
          ) : (
            // fallback UI if no main event
            <>
              <div className="lp-event-main-placeholder lp-event-main-img" />
              <h4 className="lp-event-title">No main event</h4>
              <p className="lp-event-sub">There are no main events to display.</p>
              <div className="lp-small-date">—</div>
            </>
          )}
        </div>

        {/* SIDE EVENTS */}
        <div className="lp-event-side">
          {hasSides ? (
            sideEvents.map((evt: EventItem) => (
              <div key={evt.id} className="lp-mini">
                <h5>{evt.title}</h5>
                <div className="lp-small-date">{evt.date}</div>
              </div>
            ))
          ) : (
            <>
              <div className="lp-mini">
                <h5>No upcoming events</h5>
                <div className="lp-small-date">—</div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Events;

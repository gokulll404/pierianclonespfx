import * as React from "react";
import { useState } from "react";
import { LeadershipMessageType } from "../../../utils/types";

interface LeadershipMessageProps {
  data: LeadershipMessageType[];
}

const LeadershipMessage: React.FC<LeadershipMessageProps> = ({ data }) => {
  const hasData = Array.isArray(data) && data.length > 0;
  const [index, setIndex] = useState(0);

  // If no data, show simple placeholder
  if (!hasData) {
    return (
      <div className="lp-card lp-leadership">
        <div className="lp-lead-head">
          <div className="lp-lead-title">Leadership Message</div>
        </div>
        <p className="lp-lead-text">No leadership messages available.</p>
      </div>
    );
  }

  const current = data[index];

  const prev = () =>
    setIndex((index - 1 + data.length) % data.length);
  const next = () =>
    setIndex((index + 1) % data.length);

  return (
    <div className="lp-card lp-leadership">
      <div className="lp-lead-head">
        <div className="lp-lead-title">Leadership Message</div>
        <button className="lp-viewall small">View all ➜</button>
      </div>

      <div className="lp-lead-quote">“</div>

      <p className="lp-lead-text">{current.message}</p>

      <div className="lp-lead-footer">
        <img
          src={current.avatar}
          alt={current.name}
          className="lp-lead-avatar"
        />
        <div>
          <div className="lp-lead-name">{current.name}</div>
          <div className="lp-lead-role">{current.title}</div>
        </div>

        <div className="lp-lead-nav">
          <button className="lp-circle small" onClick={prev}>◀</button>
          <button className="lp-circle small" onClick={next}>▶</button>
        </div>
      </div>
    </div>
  );
};

export default LeadershipMessage;

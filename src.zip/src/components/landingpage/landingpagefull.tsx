import * as React from 'react';
import { useEffect, useState, useContext, useRef } from "react";

import Carousel from "./components/Carousel";
import CorporateNews from "./components/CorporateNews";
import Events from "./components/Events";
import LatestNews from "./components/LatestNews";
import NewJoiners from "./components/NewJoiners";
import PhotoVideoGallery from "./components/PhotoVideoGallery";
import LeadershipMessage from "./components/LeadershipMessage";
import HrAnnouncements from "./components/HrAnnouncements";
import WelcomeOnboard from "./components/WelcomeOnboard";
import RecognizedEmployees from "./components/RecognizedEmployees";
import QuickLinks from "./components/QuickLinks";
import JobOpenings from "./components/JobOpenings";

import {
  getCarousalData,
  getCorporateEventsData,
  getCorporateNews,
  getDocumentsFromLibraryAsync,
  getHRAnnouncements,
  getJobOpeningsData,
  getLeadershipMessages,
  getNewgetOnboardEmployee,
  getNewJoiners,
  getNewsEvents,
  getQuickLinksData,
  getRecognizedEmployees,

} from "../../services/service";

import {
  CorporateNewsType,
  EventItem,
  GalleryItemType,
  HeroSlide,
  HRAnnouncementType,
  JobOpeningType,
  LeadershipMessageType,
  NewJoinerType,
  NewsEventType,
  QuickLinkType,
  RecognizedEmployeeType,
  WelcomeMessageType
} from "../../utils/types";

import { spContext } from "../../app";
import { defaultTenantUrl } from "../../utils/constant";
import "./landingpagefull.css";


const LandingPageFull: React.FC = () => {
  const { sp } = useContext(spContext);

  // 🟢 FIXED — STRICTLY TYPED STATES NOW (no more never[])
  const [carouselData, setCarouselData] = useState<HeroSlide[]>([]);
  const [corporateNewsData, setCorporateNewsData] = useState<CorporateNewsType>({
    mainEvent: null,
    sideEvents: []
  });
  const [corporateEventsData, setCorporateEventsData] = useState<{
    mainEvent: EventItem | null;
    sideEvents: EventItem[];
  }>({ mainEvent: null, sideEvents: [] });

  const [latestNewsData, setLatestNewsData] = useState<NewsEventType[]>([]);
  const [newJoinersData, setNewJoinersData] = useState<NewJoinerType[]>([]);
  const [galleryData, setGalleryData] = useState<GalleryItemType[]>([]);
  const [leadershipData, setLeadershipData] = useState<LeadershipMessageType[]>([]);
  const [hrData, setHrData] = useState<HRAnnouncementType[]>([]);
  const [welcomeData, setWelcomeData] = useState<WelcomeMessageType[]>([]);
  const [recognizedEmployees, setRecognizedEmployees] = useState<RecognizedEmployeeType[]>([]);
  const [quickLinks, setQuickLinks] = useState<QuickLinkType[]>([]);
  const [jobOpeningData, setJobOpeningData] = useState<JobOpeningType[]>([]);
 

  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);


  // SYNC RIGHT HEIGHT TO LEFT (no change)
  useEffect(() => {
    if (!leftRef.current || !rightRef.current) return;
    if (window.innerWidth < 1024) return;

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.target === leftRef.current) {
          rightRef.current!.style.height = `${entry.contentRect.height}px`;
        }
      }
    });

    resizeObserver.observe(leftRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  // LOAD ALL DATA
  useEffect(() => {
    loadAllData();
  }, []);


  // ---------------------------
  // 🔥 DATA LOADER (unchanged)
  // ---------------------------
  const loadAllData = async () => {
    try {
      // Carousal
      const carousal = (await getCarousalData(sp, "MediaGallery")) ?? [];

      setCarouselData(
        carousal.map((doc: any) => ({
          id: String(doc.Id),
          image: doc.ThumbnailURL,
          title: doc.Title,
          subtitle: doc.Description
        }))
      );


      // Corporate News
      // Corporate News
      const corpNews = (await getCorporateNews(sp, "CorporateNews")) ?? [];

      const mappedNews = corpNews.map((n: any) => ({
        id: n.Id,
        title: n.Title,
        description: n.Description,
        image: n.Image,
        date: n.Date,
        alt: n.Title
      }));

      setCorporateNewsData({
        mainEvent: mappedNews[0] ?? null,
        sideEvents: mappedNews.slice(1),
      });


      // Corporate Events
      const corpEvents = await getCorporateEventsData(sp, "CorporateEvents");
      const mappedEvents = corpEvents.map((e: any) => ({
        id: e.Id,
        title: e.Title,
        description: e.Description,
        image: e.Image,
        date: e.Date,
        alt: e.Title
      }));

      setCorporateEventsData({
        mainEvent: mappedEvents[0] ?? null,
        sideEvents: mappedEvents.slice(1)
      });

      // Latest News
      const newsEvents = await getNewsEvents(sp, "LatestNewsAndEvents");
      setLatestNewsData(newsEvents);

      // New Joiners
      const newJoiners = await getNewJoiners(sp, "NewJoinee");
      setNewJoinersData(
        newJoiners.map((nj: any) => ({
          id: String(nj.UserID),
          name: nj.EmployeeName,
          position: nj.Designation,
          avatar: nj.UserImage
        }))
      );

      // Gallery
      const files = await getDocumentsFromLibraryAsync(sp, "VideoGalleryLibrary");
      setGalleryData(
        files.map((doc: any) => ({
          id: doc.Id,
          url: `${defaultTenantUrl}${doc.File.ServerRelativeUrl}`,
          imageType: doc.FileType,
          description: doc.FileLeafRef
        }))
      );

      // Right Side Widgets
      setLeadershipData((await getLeadershipMessages(sp, "LeadershipMessage")) ?? []);
      setHrData((await getHRAnnouncements(sp, "HRAnnouncements")) ?? []);
      setQuickLinks((await getQuickLinksData(sp, "QuickLinks")) ?? []);
      setJobOpeningData((await getJobOpeningsData(sp, "JobOpenings")) ?? []);
      

      const onboard = (await getNewgetOnboardEmployee(sp, "EmployeeOnboard")) ?? [];

      setWelcomeData(
        onboard.map((item: any) => ({
          id: item?.UserID ?? "",
          message: "Welcome to the team!", // default since your SP doesn’t have this field
          employeeName: item.EmployeeName,
          employeeImage: item.Image
        }))
      );

      const recognized = (await getRecognizedEmployees(sp, "RecogonizedEmployee")) ?? [];

      setRecognizedEmployees(
        recognized.map((item: any) => ({
          id: item.ID,
          name: item.EmployeeName,
          position: item.Designation,
          department: item.Department,
          recognition: item.RecogonitionDescription,
          avatar: item.Image
        }))
      );



    } catch (err) {
      console.error("Error in LandingPageFull:", err);
    }
  };


  // ---------------------------
  // UI LAYOUT (unchanged)
  // ---------------------------
  return (
    <div className="lp-wrapper">
      {/* LEFT SECTION */}
      <div className="lp-left" ref={leftRef}>
        <Carousel slides={carouselData} />
        <CorporateNews mainNews={corporateNewsData.mainEvent} sideNews={corporateNewsData.sideEvents} />
        <Events mainEvent={corporateEventsData.mainEvent} sideEvents={corporateEventsData.sideEvents} />
    
        <div className="lp-grid-2col">
          <LatestNews newsEvents={latestNewsData} />
          <NewJoiners newJoiners={newJoinersData} />
        </div>

        <PhotoVideoGallery items={galleryData} />
      </div>

      {/* RIGHT SECTION */}
      <div className="lp-right-scroll">
        <aside className="lp-right" ref={rightRef}>
          <LeadershipMessage data={leadershipData} />
          <HrAnnouncements data={hrData} />
          <WelcomeOnboard data={welcomeData} />
          <RecognizedEmployees data={recognizedEmployees} />
          <QuickLinks quickLinks={quickLinks} />
          <JobOpenings jobOpenings={jobOpeningData} />
        </aside>
      </div>
    </div>
  );
};

export default LandingPageFull;

import * as React from "react";
import "./topbar.css";
import Logo from '../../assets/PIE_icon_f8b41a247e0d12221c86.png'

const TopNav: React.FC = () => {
  return (
    <div>
      <div className="top-nav">
        
        {/* LEFT SIDE */}
        <div className="left">
          <a
            href="/"
            className="logo"
            style={{
              height: "64px",
              maxHeight: "64px",
              width: "64px",
              maxWidth: "64px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <img
              src={Logo}
              alt="PIE Logo"
              style={{
                height: "100%",
                width: "100%",
                objectFit: "contain"
              }}
            />
          </a>

          <p className="insights-nav">Insights to Impact</p>
        </div>

        {/* RIGHT SIDE — DESKTOP */}
        <div className="right desktop">


          <div className="search-container">
            <input
              type="text"
              placeholder="Search..."
              className="search-input"
            />
            <button className="search-button" type="button">
              <span className="search-icon" />
            </button>
          </div>

          <img className="avatar" src="" alt="user" />
        </div>

        {/* MOBILE MENU TOGGLE */}
        <div className="menu-toggle mobile">
          <span>☰</span>
        </div>
      </div>

      {/* BREADCRUMBS */}
      <div className="bread-crumps-div">
        {/* Breadcrumbs placeholder */}
      </div>
    </div>
  );
};

export default TopNav;

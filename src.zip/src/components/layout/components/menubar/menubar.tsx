import * as React from "react";
import "./menuBar.css";

const MenuBar: React.FC = () => {

    return (
        <div className="menuBar">

            {/* Left Section */}
            <div className="leftSection">
                <p className="dateTime">09:45 AM Monday, January 1, 2025</p>
                <h2 className="greeting">
                    Good Morning, User <span className="emoji">👋</span>
                </h2>
            </div>

            {/* Right Section (Apps) */}
            <div className="rightSection">

                <div className="appContainer">
                    <div className="appIcon" style={{ backgroundColor: "#f97316" }}></div>
                    <p className="appTitle">Need Help?</p>
                </div>

                <div className="appContainer">
                    <div className="appIcon" style={{ backgroundColor: "#eab308" }}></div>
                    <p className="appTitle">Employee Directory</p>
                </div>

                <div className="appContainer">
                    <div className="appIcon" style={{ backgroundColor: "#3b82f6" }}></div>
                    <p className="appTitle">Business Units</p>
                </div>
                

            </div>

        </div>
    );
};

export default MenuBar;
